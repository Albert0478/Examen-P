<template>
    <div>
      <h1>Acerca de</h1>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestiae in maxime dignissimos labore
         sequi ipsam repellendus tenetur eos! Voluptatibus eaque corrupti aspernatur aut nulla, 
         laboriosam ea! Vitae eum aperiam porro?</p>
    </div>
  </template>
  