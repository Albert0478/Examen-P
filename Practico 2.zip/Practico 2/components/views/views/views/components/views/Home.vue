<template>
    <div>
      <h1>Inicio</h1>
      <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio a voluptates sapiente ducimus
         eos molestiae commodi inventore eius omnis esse asperiores sint, et blanditiis eum eveniet 
         consectetur saepe consequatur porro!</p>
    </div>
  </template>
  