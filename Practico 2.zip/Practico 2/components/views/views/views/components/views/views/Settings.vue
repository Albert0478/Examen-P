<template>
    <div>
      <h1>Configuración</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum praesentium nisi vitae maxime
         ipsam temporibus rem eius nam ab? Voluptas accusamus dolor 
         a illum exercitationem nesciunt ea velit minima debitis!</p>
    </div>
  </template>